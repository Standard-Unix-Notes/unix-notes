# Uninstalling Standard(?) Unix Notes

## Uninstalling

If you want to remove the *notes* system then you can perform one of 
the following actions:

- *sudo make uninstall* from either a git clone or the release tarball
- *sudo dpkg -r unix-notes-(VER).deb* from the .deb package from the 
latest release

