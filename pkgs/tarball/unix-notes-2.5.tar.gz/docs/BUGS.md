#			BUGS

## REPORTING

Please report any bugs found to the GitHub repo by filing an issue 
there.

https://github.com/Standard-Unix-Notes/unix-notes/issues


## PROGRESS

Progress on bug fixes will be discussed in the comments relating to a 
previously filed issue.


## PATCHES

Bug fixes will always be added to HEAD of the repo commit log but may 
not automatically be packaged and released immediately. You will always 
be able to download the code direct from the GitHub repo and either 
'sudo make install' to install the patched version into your system. 
You may also be able to build a local package of the upto date code at 
HEAD. For information on building a package with the latest code in the 
repo see PACKAGING.


